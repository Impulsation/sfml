// Random.h

#ifndef RANDOM_H
#define RANDOM_H

#include "Range.h"

int Random(Range r);

int Random(int a, int b);

#endif // RANDOM_H
