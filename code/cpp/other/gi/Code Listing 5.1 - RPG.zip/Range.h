// Range.h

#ifndef RANGE_H
#define RANGE_H

// Defines a range [mLow, mHigh].
struct Range
{
	int mLow;
	int mHigh;
};

#endif //RANGE_H